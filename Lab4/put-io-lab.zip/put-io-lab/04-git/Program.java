public class QuotientRemainder {

  public static void main(String[] args) {

    int dividend = 25, divisor = 4; //deklaracja zmiennych

    int quotient = dividend / divisor; //dzielenie
    int remainder = dividend % divisor; //modulo

    System.out.println("Quotient = " + quotient); //wypisz wynik dzielenia
    System.out.println("Remainder = " + remainder); //wypisz wynik modulo
  }
}