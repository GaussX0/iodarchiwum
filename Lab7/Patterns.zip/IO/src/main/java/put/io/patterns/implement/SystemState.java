package put.io.patterns.implement;

public class SystemState implements SystemStateObserver {

    // CPU load in percentage
    private double cpu = 0.0;

    // CPU temperature in C
    private double cpuTemp = 0.0;

    // available memory in Mega Bytes
    private double memory = 0.0;

    // number of USB devices
    private int USBDevices = 0;


    public SystemState(double cpu, double cpuTemp, double memory, int USBDevices) {
        this.cpu = cpu;
        this.cpuTemp = cpuTemp;
        this.memory = memory;
        this.USBDevices = USBDevices;
    }

    public void update(SystemMonitor monitor) {
        monitor.getLastSystemState();
    }

    public double getCpu() {
        return cpu;
    }

    public double getAvailableMemory() {
        return memory;
    }


    public int getUSBDevices() {
        return USBDevices;
    }


    public double getCpuTemp() {
        return cpuTemp;
    }
}
