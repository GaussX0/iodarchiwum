package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver {
    private int USBDevices;
    USBDeviceObserver() {

    }
    public void update(SystemMonitor monitor) {
        this.USBDevices = monitor.getLastSystemState().getUSBDevices();
    }

    public void printInfo() {
        System.out.println(String.format("USB devices: %d", USBDevices));
    }
}
