package put.io.patterns.implement;

public class SystemGarbageCollectorObserver implements SystemStateObserver {
    private double memory;
    SystemGarbageCollectorObserver() {

    }
    public void update(SystemMonitor monitor) {
        this.memory = monitor.getLastSystemState().getAvailableMemory();
    }

    public void printInfo() {
        // Garbage collector out of memory
        if (memory < 100.00) {
            System.out.println("> Running garbage collector...");
        }
    }
}
