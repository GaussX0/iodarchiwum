package put.io.patterns.implement;

public class SystemCoolerObserver implements SystemStateObserver {
    private double temp;
    SystemCoolerObserver() {

    }
    public void update(SystemMonitor monitor) {
        this.temp = monitor.getLastSystemState().getCpuTemp();
    }

    public void printInfo() {
        // Increase CPU cooling if the temperature is to high
        if (temp > 60.00){
            System.out.println("> Increasing cooling of the CPU...");
        }
    }
}
